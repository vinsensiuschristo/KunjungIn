package com.bangkit.kunjungin.data.local.pref

class AddUserRecommendationRequest(
    val place_type_id: List<String>,
)