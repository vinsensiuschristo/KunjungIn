package com.bangkit.kunjungin.data.local.pref

import android.content.Context
import androidx.datastore.core.DataStore
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map


val Context.dataStore: DataStore<Preferences> by preferencesDataStore(name = "session")

class UserPreferences private constructor(private val dataStore: DataStore<Preferences>) {

    suspend fun saveSession(user: UserModel) {
        dataStore.edit { preferences ->
            preferences[EMAIL_KEY] = user.email
            preferences[TOKEN_KEY] = user.token
            preferences[USER_NAME] = user.name
            preferences[CITY_ID] = user.cityId
            preferences[USER_ID] = user.userId
            preferences[RECOMMENDATION_STATUS] = user.recommendationStatus
            preferences[IS_LOGIN_KEY] = user.isLogin
        }
    }

    fun getSession(): Flow<UserModel> {
        return dataStore.data.map { preferences ->
            UserModel(
                preferences[EMAIL_KEY] ?: "",
                preferences[TOKEN_KEY] ?: "",
                preferences[USER_NAME] ?: "",
                preferences[CITY_ID] ?: 0,
                preferences[USER_ID] ?:0,
                preferences[RECOMMENDATION_STATUS] ?: false,
                preferences[IS_LOGIN_KEY] ?: false
            )
        }
    }

    suspend fun login() {
        dataStore.edit { preferences ->
            preferences[IS_LOGIN_KEY] = true
        }
    }

    suspend fun logout() {
        dataStore.edit { preferences ->
            preferences.clear()
        }
    }

    suspend fun updateRecommendationStatus(recommendationStatus: Boolean) {
        dataStore.edit { preferences ->
            preferences[RECOMMENDATION_STATUS] = recommendationStatus
        }
    }

    companion object {
        @Volatile
        private var INSTANCE: UserPreferences? = null

        private val EMAIL_KEY = stringPreferencesKey("email")
        private val TOKEN_KEY = stringPreferencesKey("token")
        private val USER_NAME = stringPreferencesKey("name")
        private val CITY_ID = intPreferencesKey("cityId")
        private val USER_ID = intPreferencesKey("userId")
        private val RECOMMENDATION_STATUS = booleanPreferencesKey("recommendationStatus")
        private val IS_LOGIN_KEY = booleanPreferencesKey("isLogin")

        fun getInstance(dataStore: DataStore<Preferences>): UserPreferences {
            return INSTANCE ?: synchronized(this) {
                val instance = UserPreferences(dataStore)
                INSTANCE = instance
                instance
            }
        }
    }
}