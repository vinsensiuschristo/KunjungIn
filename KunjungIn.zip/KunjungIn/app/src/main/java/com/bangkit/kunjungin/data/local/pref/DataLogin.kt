package com.bangkit.kunjungin.data.local.pref

data class DataLogin(
    var email: String,
    var password: String,
)