package com.bangkit.kunjungin.data.local.pref

data class City(val id: Int, val name: String)
