package com.bangkit.kunjungin.data.local.pref

data class DataSignup(
    var email: String,
    var name: String,
    var password: String,
    var address: String,
    var city_id: Int,
)
